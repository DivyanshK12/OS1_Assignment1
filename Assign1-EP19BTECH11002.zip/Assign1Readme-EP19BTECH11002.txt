Instructions for use :
1. Download the main.c file. cd to the folder containing it
2. Ensure a file named inp.txt exits with the N and K values. Example file is included (First value N, second value K)
3. Run the command : 'gcc main.c -o main' to compile the code
4. Execute using ./main